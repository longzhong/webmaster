﻿namespace LONG.Data
{
	public class SqlAzureProvider : SqlServerProvider
	{
	}
}
