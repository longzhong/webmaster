﻿namespace LONG.Data
{
    public interface IExecute
    {
        int Execute();        
    }
}