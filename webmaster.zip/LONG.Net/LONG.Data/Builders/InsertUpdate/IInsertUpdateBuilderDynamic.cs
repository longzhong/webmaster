﻿using System.Dynamic;

namespace LONG.Data
{
	public interface IInsertUpdateBuilderDynamic
	{
		BuilderData Data { get; }
		dynamic Item { get; }
		IInsertUpdateBuilderDynamic Column(string columnName, object value, DataTypes parameterType = DataTypes.Object, int size = 0);
		IInsertUpdateBuilderDynamic Column(string propertyName, DataTypes parameterType = DataTypes.Object, int size = 0);
	}
}
